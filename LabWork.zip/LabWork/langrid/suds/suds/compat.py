
basestring = unicode = str
