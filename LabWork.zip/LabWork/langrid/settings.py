_config = {
    'baseUrl': 'https://langrid.org/service_manager/wsdl/kyoto1.langrid:',
    'id': 'sil.ritsumei',
    'password': 'Shakaichinou'
}