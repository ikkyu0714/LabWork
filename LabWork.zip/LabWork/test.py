from nltk.corpus import wordnet as wn




"""import wn

en = wn.Wordnet('oewn:2021') # 英語2021
ja = wn.Wordnet('omw-ja:1.4') # 日本語
zh = wn.Wordnet('omw-cmn:1.4') # 中国語
#mul = wn.Wordnet('omw:1.4')
ss = wn.synsets('ゴボウ', lexicon='omw-ja:1.4')[0]
print(ss.lemmas(lang='ja'))
#print(ja.synsets(ss[0]))"""